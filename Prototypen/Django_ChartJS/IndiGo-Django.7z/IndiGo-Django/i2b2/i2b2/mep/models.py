from django.db import models
import pandas as pd
import numpy as np

# Create your models here.

#data = pd.read_csv("C:/Users/nadja/Documents/beispieldaten.csv", sep=";", header=0, encoding="utf8"),
#count = data.groupby('Sex').size(),
#list = count.tolist(),

   
   
   
   
