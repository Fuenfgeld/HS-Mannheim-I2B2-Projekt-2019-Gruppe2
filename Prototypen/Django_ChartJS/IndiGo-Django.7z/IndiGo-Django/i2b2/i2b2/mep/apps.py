from django.apps import AppConfig


class mepConfig(AppConfig):
    name = 'mep'
